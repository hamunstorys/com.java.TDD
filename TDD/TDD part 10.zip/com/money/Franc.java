package com.money;

public class Franc extends Money {

	
	public Franc(int amount, String currency) {
		super(amount, currency);
	}

	public Money times(int multiplier) {
		return new Franc(getAmount() * multiplier,getCurrency());
	}

}