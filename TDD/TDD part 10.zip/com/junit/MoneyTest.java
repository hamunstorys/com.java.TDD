package com.junit;

import org.junit.Test;

import com.money.Dollar;
import com.money.Franc;
import com.money.Money;

import junit.framework.TestCase;

public class MoneyTest extends TestCase {

	@Test

	public void testEquality() {
		assertTrue(new Money(5, "USD").equals(new Dollar(5, "USD")));
		assertFalse(new Money(5, "USD").equals(new Dollar(6, "USD")));

	}

	@Test
	public void tesDollartMiltiplication() {
		Dollar five = new Dollar(5, "USD");

		assertEquals(new Dollar(10, "USD"), five.times(2));

		five.setAmount(5);
		assertEquals(new Dollar(15, "USD"), five.times(3));

	}

	@Test
	public void tesFranctMiltiplication() {
		Franc five = new Franc(5, "CHF");

		assertEquals(new Franc(10, "CHF"), five.times(2));

		five.setAmount(5);
		assertEquals(new Franc(15, "CHF"), five.times(3));

	}

	@Test
	public void testCurrency() {
		assertEquals("USD", Money.dollar(1).getCurrency());
		assertEquals("CHF", Money.franc(1).getCurrency());
	}

}