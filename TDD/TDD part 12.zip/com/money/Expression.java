package com.money;

public interface Expression {

}
