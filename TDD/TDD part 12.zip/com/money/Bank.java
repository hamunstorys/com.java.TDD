package com.money;

public class Bank {

	public Money reduce(Expression source, String to) {
		return Money.dollar(10);
	}

}
