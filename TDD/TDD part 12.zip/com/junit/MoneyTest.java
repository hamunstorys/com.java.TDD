package com.junit;

import org.junit.Test;

import com.money.Bank;
import com.money.Dollar;
import com.money.Expression;
import com.money.Money;

import junit.framework.TestCase;

public class MoneyTest extends TestCase {

	private Object bank;

	@Test
	public void testEquality() {
		assertTrue(new Money(5, "$").equals(new Dollar(5, "$")));
		assertFalse(new Money(5, "$").equals(new Dollar(6, "$")));

	}

	@Test
	public void testSimpleAddition() {
		Money five = Money.dollar(5);
		Expression sum = five.plus(five);
		Bank bank = new Bank();
		Money reduced = bank.reduce(sum, "USD");
		assertEquals(Money.dollar(10), reduced);
	}
}