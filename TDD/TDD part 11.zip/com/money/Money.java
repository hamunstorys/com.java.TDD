package com.money;

public class Money {

	private int amount;
	private String currency;

	public Money(int amount, String currency) {
		setAmount(amount);
		setCurrency(currency);
	}

	public static Money dollar(int amount) {
		return new Money(amount, "USD");
	}

	public static Money franc(int amount) {
		return new Money(amount, "CHF");
	}

	public Money times(int multiplier) {
		return new Money(getAmount() * multiplier, getCurrency());
	}

	@Override
	public boolean equals(Object o) {
		Money money = (Money) o;
		System.out.println(toString());
		return amount == money.amount && getCurrency().equals(money.getCurrency());
	}

	public String toString() {
		return getAmount() + " " + getCurrency();
	}

	/* getter */

	public int getAmount() {
		return amount;
	}

	public String getCurrency() {
		return currency;
	}

	/* setter */

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

}
