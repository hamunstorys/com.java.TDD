package com.money;

public class Dollar {

	private int amount;

	public Dollar(int amount) {
		this.amount = amount;
	}

	public Dollar times(int multiplyer) {
		return new Dollar(amount *= multiplyer);
	}

	@Override
	public boolean equals(Object obj) {
		Dollar dollar = (Dollar) obj;
		System.out.println("dollar.amount:" + dollar.amount);
		System.out.println("this.amount:" + this.amount);

		return dollar.amount == this.amount;
	}

	/* getter */

	public int getAmount() {
		return amount;
	}

	/* setter */

	public void setAmount(int amount) {
		this.amount = amount;
	}

}