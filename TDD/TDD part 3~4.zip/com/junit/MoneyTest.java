package com.junit;

import static org.junit.Assert.fail;

import org.junit.Test;

import com.money.Dollar;

import junit.framework.TestCase;

public class MoneyTest extends TestCase {

	@Test
	public void testMiltiplication() {
		Dollar five = new Dollar(5);

		assertEquals(new Dollar(10),five.times(2));
	
		five.setAmount(5);
		assertEquals(new Dollar(15),five.times(3));
		
	}

	@Test

	public void testEquality() {
		assertTrue(new Dollar(5).equals(new Dollar(5)));
		assertFalse(new Dollar(5).equals(new Dollar(6)));

	}

}