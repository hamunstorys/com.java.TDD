package com.junit;

public class TestCase {

}
