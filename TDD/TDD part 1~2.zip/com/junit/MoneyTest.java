package com.junit;

import static org.junit.Assert.fail;

import org.junit.Test;

import com.money.Dollar;

import junit.framework.TestCase;

public class MoneyTest extends TestCase {

	@Test
	public void testMiltiplication() {
		Dollar five = new Dollar(5);
		Dollar product = new Dollar(5*2);
		

		assertEquals(10, product.amount);
		
		product = five.times(3);
		assertEquals(15, product.amount);
	}
	
}