package com.money;

public class Dollar {

	public int amount;

	public Dollar(int amount) {
		this.amount = amount;
	}

	public Dollar times(int multiplyer) {
		return 
				new Dollar(this.amount*=multiplyer);
	}

}