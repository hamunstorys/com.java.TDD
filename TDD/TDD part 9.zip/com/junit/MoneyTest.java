package com.junit;

import org.junit.Test;

import com.money.Dollar;
import com.money.Franc;
import com.money.Money;

import junit.framework.TestCase;

public class MoneyTest extends TestCase {

	/* Dollar Test */

	@Test
	public void testMiltiplication() {
		Money five = Money.dollar(5);

		assertEquals(Money.dollar(10), five.times(2));

		five.setAmount(5);
		assertEquals(new Dollar(15, "USD"), five.times(3));

	}

	@Test

	public void testEquality() {
		assertTrue(new Dollar(5, "USD").equals(new Dollar(5, "USD")));
		assertFalse(new Dollar(5, "USD").equals(new Dollar(6, "USD")));

	}

	@Test
	public void tesDollartMiltiplication() {
		Dollar five = new Dollar(5, "USD");

		assertEquals(new Dollar(10, "USD"), five.times(2));

		five.setAmount(5);
		assertEquals(new Dollar(15, "USD"), five.times(3));

	}

	@Test
	public void tesFranctMiltiplication() {
		Franc five = new Franc(5, "CHF");

		assertEquals(new Franc(10, "CHF"), five.times(2));

		five.setAmount(5);
		assertEquals(new Franc(15, "CHF"), five.times(3));

	}

	@Test
	public void testCurrency() {
		assertEquals("USD", Money.dollar(1).getCurrency());
		assertEquals("CHF", Money.franc(1).getCurrency());
	}

}