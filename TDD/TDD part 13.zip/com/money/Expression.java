package com.money;

public interface Expression {

	Money reduce(String to);

}
